ModTools для Nukkit-MOT (Java 17)

СБОРКА
  mvn clean package
  Готовый файл: target/ModTools-1.0.0.jar -> положить в plugins/

  На ПК: IntelliJ IDEA -> открыть папку проекта -> Maven -> Lifecycle -> package.
  Нужен JDK 17 и интернет (Maven скачает Nukkit-MOT с repo.lanink.cn).

КОМАНДЫ
  /ban <ник> <минуты 1-100000> <причина 1-30>   (/tempban то же самое)
  /unban <ник>
  /mute <ник> <минуты 1-3000> <причина 1-30>
  /unmute <ник>
  /kick <ник> <причина 1-30>
  /rtp
  /home [название]   /sethome [название]   /delhome [название]   (до 5 домов)

ПРАВА (LuckPerms)
  modtools.ban, modtools.unban, modtools.kick, modtools.mute, modtools.unmute
  modtools.exempt      - иммунитет к бану/муту/кику
  modtools.rtp, modtools.rtp.bypass (без кулдауна)
  modtools.home, modtools.sethome, modtools.delhome
  По умолчанию наказания только для OP, rtp и home для всех.
  Пример: /lp group moder permission set modtools.ban true

НАСТРОЙКИ
  plugins/ModTools/config.yml: лимиты, радиус и кулдаун rtp, все сообщения.
  Данные: bans.json, mutes.json, homes.json в той же папке.
