package modtools;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.block.BlockCactus;
import cn.nukkit.block.BlockMagma;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerChatEvent;
import cn.nukkit.event.player.PlayerCommandPreprocessEvent;
import cn.nukkit.event.player.PlayerPreLoginEvent;
import cn.nukkit.level.Level;
import cn.nukkit.level.Location;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.TextFormat;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class ModTools extends PluginBase implements Listener {

    /** Бан или мут. */
    static class Punish {
        String name;
        String reason;
        String by;
        long until; // unix ms
    }

    /** Точка дома. */
    static class Home {
        String world;
        double x, y, z, yaw, pitch;
    }

    private final Map<String, Punish> bans = new LinkedHashMap<>();
    private final Map<String, Punish> mutes = new LinkedHashMap<>();
    private final Map<String, Map<String, Home>> homes = new LinkedHashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Random random = new Random();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private File bansFile;
    private File mutesFile;
    private File homesFile;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        saveDefaultConfig();

        bansFile = new File(getDataFolder(), "bans.json");
        mutesFile = new File(getDataFolder(), "mutes.json");
        homesFile = new File(getDataFolder(), "homes.json");

        Type punishType = new TypeToken<LinkedHashMap<String, Punish>>() {}.getType();
        Type homesType = new TypeToken<LinkedHashMap<String, LinkedHashMap<String, Home>>>() {}.getType();
        bans.putAll(load(bansFile, punishType, new LinkedHashMap<String, Punish>()));
        mutes.putAll(load(mutesFile, punishType, new LinkedHashMap<String, Punish>()));
        homes.putAll(load(homesFile, homesType, new LinkedHashMap<String, Map<String, Home>>()));

        registerCommands();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ModTools включён. Банов: " + bans.size() + ", мутов: " + mutes.size());
    }

    @Override
    public void onDisable() {
        save(bansFile, bans);
        save(mutesFile, mutes);
        save(homesFile, homes);
    }

    // ------------------------------------------------------------------ storage

    private <T> T load(File f, Type type, T def) {
        if (!f.exists()) return def;
        try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            T v = gson.fromJson(r, type);
            return v == null ? def : v;
        } catch (Exception e) {
            getLogger().error("Не удалось прочитать " + f.getName(), e);
            return def;
        }
    }

    private void save(File f, Object data) {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            gson.toJson(data, w);
        } catch (IOException e) {
            getLogger().error("Не удалось сохранить " + f.getName(), e);
        }
    }

    // ------------------------------------------------------------------ commands

    private class Cmd extends Command {
        Cmd(String name, String desc, String usage, String perm) {
            super(name, desc, usage);
            setPermission(perm);
        }

        @Override
        public boolean execute(CommandSender sender, String label, String[] args) {
            if (!testPermission(sender)) return false;
            try {
                handle(sender, getName().toLowerCase(Locale.ROOT), args);
            } catch (Exception e) {
                sender.sendMessage(TextFormat.RED + "Внутренняя ошибка команды, смотри консоль.");
                getLogger().error("Ошибка в команде /" + getName(), e);
            }
            return true;
        }
    }

    private void registerCommands() {
        Map<String, Command> known = getServer().getCommandMap().getCommands();
        String[][] defs = {
                {"ban", "Забанить игрока", "/ban <ник> <минуты> <причина>", "modtools.ban"},
                {"tempban", "Забанить игрока (то же, что /ban)", "/tempban <ник> <минуты> <причина>", "modtools.ban"},
                {"unban", "Разбанить игрока", "/unban <ник>", "modtools.unban"},
                {"kick", "Кикнуть игрока", "/kick <ник> <причина>", "modtools.kick"},
                {"mute", "Замутить игрока", "/mute <ник> <минуты> <причина>", "modtools.mute"},
                {"unmute", "Снять мут", "/unmute <ник>", "modtools.unmute"},
                {"rtp", "Случайная телепортация", "/rtp", "modtools.rtp"},
                {"home", "Телепорт домой", "/home [название]", "modtools.home"},
                {"sethome", "Установить дом", "/sethome [название]", "modtools.sethome"},
                {"delhome", "Удалить дом", "/delhome [название]", "modtools.delhome"},
        };
        for (String[] d : defs) {
            known.remove(d[0]); // убираем встроенную команду с тем же именем
            Cmd cmd = new Cmd(d[0], d[1], d[2], d[3]);
            getServer().getCommandMap().register("modtools", cmd);
            if (getServer().getCommandMap().getCommand(d[0]) != cmd) {
                getLogger().warning("/" + d[0] + " занята другим плагином, доступна как /modtools:" + d[0]);
            }
        }
    }

    private void handle(CommandSender s, String cmd, String[] a) {
        switch (cmd) {
            case "ban":
            case "tempban":
                cmdPunish(s, a, true);
                break;
            case "mute":
                cmdPunish(s, a, false);
                break;
            case "kick":
                cmdKick(s, a);
                break;
            case "unban":
                cmdUndo(s, a, true);
                break;
            case "unmute":
                cmdUndo(s, a, false);
                break;
            case "rtp":
                cmdRtp(s);
                break;
            case "home":
                cmdHome(s, a);
                break;
            case "sethome":
                cmdSetHome(s, a);
                break;
            case "delhome":
                cmdDelHome(s, a);
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ ban / mute / kick

    private void cmdPunish(CommandSender s, String[] a, boolean ban) {
        int max = ban ? cfgInt("limits.max-ban-minutes", 100000) : cfgInt("limits.max-mute-minutes", 3000);
        int rmax = cfgInt("limits.reason-max-length", 30);
        String usage = ban ? "usage-ban" : "usage-mute";
        if (a.length < 3) {
            s.sendMessage(msg(usage, "max", max, "rmax", rmax));
            return;
        }
        Long minutes = parseMinutes(a[1], max);
        if (minutes == null) {
            s.sendMessage(msg("bad-time", "max", max));
            return;
        }
        String reason = parseReason(a, 2, rmax);
        if (reason == null) {
            s.sendMessage(msg("bad-reason", "rmax", rmax));
            return;
        }
        Player online = findOnline(a[0]);
        if (online != null && online.hasPermission("modtools.exempt")) {
            s.sendMessage(msg("exempt", "player", online.getName()));
            return;
        }
        String name = online != null ? online.getName() : a[0];

        Punish p = new Punish();
        p.name = name;
        p.reason = reason;
        p.by = s.getName();
        p.until = System.currentTimeMillis() + minutes * 60_000L;

        if (ban) {
            bans.put(key(name), p);
            save(bansFile, bans);
        } else {
            mutes.put(key(name), p);
            save(mutesFile, mutes);
        }
        s.sendMessage(msg(ban ? "ban-done" : "mute-done",
                "player", name, "time", fmt(minutes), "reason", reason));

        if (online != null) {
            if (ban) {
                online.kick(msg("ban-screen", "reason", reason, "time", fmt(minutes), "by", p.by), false);
            } else {
                online.sendMessage(msg("muted-notify", "reason", reason, "time", fmt(minutes), "by", p.by));
            }
        }
    }

    private void cmdKick(CommandSender s, String[] a) {
        int rmax = cfgInt("limits.reason-max-length", 30);
        if (a.length < 2) {
            s.sendMessage(msg("usage-kick", "rmax", rmax));
            return;
        }
        String reason = parseReason(a, 1, rmax);
        if (reason == null) {
            s.sendMessage(msg("bad-reason", "rmax", rmax));
            return;
        }
        Player target = findOnline(a[0]);
        if (target == null) {
            s.sendMessage(msg("player-offline", "player", a[0]));
            return;
        }
        if (target.hasPermission("modtools.exempt")) {
            s.sendMessage(msg("exempt", "player", target.getName()));
            return;
        }
        s.sendMessage(msg("kick-done", "player", target.getName(), "reason", reason));
        target.kick(msg("kick-screen", "reason", reason, "by", s.getName()), false);
    }

    private void cmdUndo(CommandSender s, String[] a, boolean ban) {
        if (a.length < 1) {
            s.sendMessage(msg(ban ? "usage-unban" : "usage-unmute"));
            return;
        }
        Map<String, Punish> map = ban ? bans : mutes;
        Punish removed = map.remove(key(a[0]));
        if (removed == null) {
            s.sendMessage(msg(ban ? "not-banned" : "not-muted", "player", a[0]));
            return;
        }
        save(ban ? bansFile : mutesFile, map);
        s.sendMessage(msg(ban ? "unban-done" : "unmute-done", "player", removed.name));
        if (!ban) {
            Player online = findOnline(a[0]);
            if (online != null) online.sendMessage(msg("unmute-notify"));
        }
    }

    // ------------------------------------------------------------------ rtp

    private void cmdRtp(CommandSender s) {
        if (!(s instanceof Player)) {
            s.sendMessage(msg("only-player"));
            return;
        }
        Player p = (Player) s;
        Level level = p.getLevel();
        if (level.getDimension() != Level.DIMENSION_OVERWORLD) {
            s.sendMessage(msg("rtp-wrong-world"));
            return;
        }

        long now = System.currentTimeMillis();
        int cooldown = cfgInt("rtp.cooldown-seconds", 300);
        if (!p.hasPermission("modtools.rtp.bypass")) {
            Long last = rtpCooldown.get(p.getUniqueId());
            if (last != null && now - last < cooldown * 1000L) {
                long left = (cooldown * 1000L - (now - last) + 999) / 1000;
                s.sendMessage(msg("rtp-cooldown", "sec", left));
                return;
            }
        }

        int minR = cfgInt("rtp.min-radius", 300);
        int maxR = Math.max(minR + 1, cfgInt("rtp.max-radius", 5000));
        int attempts = cfgInt("rtp.attempts", 15);
        int cx = level.getSpawnLocation().getFloorX();
        int cz = level.getSpawnLocation().getFloorZ();

        for (int i = 0; i < attempts; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double r = Math.sqrt(random.nextDouble() * ((double) maxR * maxR - (double) minR * minR)
                    + (double) minR * minR);
            int x = cx + (int) Math.round(Math.cos(angle) * r);
            int z = cz + (int) Math.round(Math.sin(angle) * r);

            int top = level.getHighestBlockAt(x, z);
            for (int gy = top + 1; gy >= top - 1; gy--) {
                if (gy < 1 || gy > 250) continue;
                if (!isSafe(level, x, gy, z)) continue;
                p.teleport(new Location(x + 0.5, gy + 1, z + 0.5, p.getYaw(), p.getPitch(), level));
                rtpCooldown.put(p.getUniqueId(), now);
                s.sendMessage(msg("rtp-done", "x", x, "y", gy + 1, "z", z));
                return;
            }
        }
        s.sendMessage(msg("rtp-fail"));
    }

    private boolean isSafe(Level level, int x, int gy, int z) {
        Block ground = level.getBlock(x, gy, z);
        if (!ground.isSolid()) return false;
        if (ground instanceof BlockCactus || ground instanceof BlockMagma) return false;
        return level.getBlock(x, gy + 1, z).getId() == 0
                && level.getBlock(x, gy + 2, z).getId() == 0;
    }

    // ------------------------------------------------------------------ homes

    private static boolean validHomeName(String n) {
        return n.matches("[\\p{L}\\p{N}_-]{1,16}");
    }

    private void cmdSetHome(CommandSender s, String[] a) {
        if (!(s instanceof Player)) {
            s.sendMessage(msg("only-player"));
            return;
        }
        Player p = (Player) s;
        String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
        if (!validHomeName(name)) {
            s.sendMessage(msg("home-bad-name"));
            return;
        }
        int max = cfgInt("limits.max-homes", 5);
        Map<String, Home> mine = homes.computeIfAbsent(key(p.getName()), k -> new LinkedHashMap<>());
        if (!mine.containsKey(name) && mine.size() >= max) {
            s.sendMessage(msg("home-limit", "max", max));
            return;
        }
        Home h = new Home();
        h.world = p.getLevel().getFolderName();
        h.x = p.getX();
        h.y = p.getY();
        h.z = p.getZ();
        h.yaw = p.getYaw();
        h.pitch = p.getPitch();
        mine.put(name, h);
        save(homesFile, homes);
        s.sendMessage(msg("home-set", "name", name, "count", mine.size(), "max", max));
    }

    private void cmdDelHome(CommandSender s, String[] a) {
        if (!(s instanceof Player)) {
            s.sendMessage(msg("only-player"));
            return;
        }
        Player p = (Player) s;
        Map<String, Home> mine = homes.get(key(p.getName()));
        if (mine == null || mine.isEmpty()) {
            s.sendMessage(msg("home-none"));
            return;
        }
        String name;
        if (a.length > 0) {
            name = a[0].toLowerCase(Locale.ROOT);
        } else if (mine.containsKey("home")) {
            name = "home";
        } else if (mine.size() == 1) {
            name = mine.keySet().iterator().next();
        } else {
            s.sendMessage(msg("home-list", "homes", String.join(", ", mine.keySet()),
                    "count", mine.size(), "max", cfgInt("limits.max-homes", 5)));
            return;
        }
        if (mine.remove(name) == null) {
            s.sendMessage(msg("home-not-found", "name", name));
            return;
        }
        if (mine.isEmpty()) homes.remove(key(p.getName()));
        save(homesFile, homes);
        s.sendMessage(msg("home-deleted", "name", name));
    }

    private void cmdHome(CommandSender s, String[] a) {
        if (!(s instanceof Player)) {
            s.sendMessage(msg("only-player"));
            return;
        }
        Player p = (Player) s;
        Map<String, Home> mine = homes.get(key(p.getName()));
        if (mine == null || mine.isEmpty()) {
            s.sendMessage(msg("home-none"));
            return;
        }
        String name;
        if (a.length > 0) {
            name = a[0].toLowerCase(Locale.ROOT);
        } else if (mine.containsKey("home")) {
            name = "home";
        } else if (mine.size() == 1) {
            name = mine.keySet().iterator().next();
        } else {
            s.sendMessage(msg("home-list", "homes", String.join(", ", mine.keySet()),
                    "count", mine.size(), "max", cfgInt("limits.max-homes", 5)));
            return;
        }
        Home h = mine.get(name);
        if (h == null) {
            s.sendMessage(msg("home-not-found", "name", name));
            return;
        }
        Level level = getServer().getLevelByName(h.world);
        if (level == null) {
            getServer().loadLevel(h.world);
            level = getServer().getLevelByName(h.world);
        }
        if (level == null) {
            s.sendMessage(msg("home-world-missing"));
            return;
        }
        p.teleport(new Location(h.x, h.y, h.z, h.yaw, h.pitch, level));
        s.sendMessage(msg("home-tp", "name", name));
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPreLogin(PlayerPreLoginEvent e) {
        Player p = e.getPlayer();
        Punish b = active(bans, bansFile, key(p.getName()));
        if (b == null) return;
        e.setKickMessage(msg("banned-login", "reason", b.reason, "time", fmt(remainingMin(b)), "by", b.by));
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(PlayerChatEvent e) {
        Player p = e.getPlayer();
        Punish m = active(mutes, mutesFile, key(p.getName()));
        if (m == null) return;
        e.setCancelled(true);
        p.sendMessage(msg("muted-chat", "reason", m.reason, "time", fmt(remainingMin(m))));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String text = e.getMessage();
        if (text == null || !text.startsWith("/")) return;
        String first = text.substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        int colon = first.indexOf(':');
        if (colon >= 0) first = first.substring(colon + 1);

        List<String> blocked = getConfig().getStringList("mute.blocked-commands");
        if (blocked == null || !blocked.contains(first)) return;

        Player p = e.getPlayer();
        Punish m = active(mutes, mutesFile, key(p.getName()));
        if (m == null) return;
        e.setCancelled(true);
        p.sendMessage(msg("muted-chat", "reason", m.reason, "time", fmt(remainingMin(m))));
    }

    // ------------------------------------------------------------------ helpers

    /** Возвращает активное наказание или null. Просроченное удаляет. */
    private Punish active(Map<String, Punish> map, File file, String key) {
        Punish p = map.get(key);
        if (p == null) return null;
        if (p.until <= System.currentTimeMillis()) {
            map.remove(key);
            save(file, map);
            return null;
        }
        return p;
    }

    private long remainingMin(Punish p) {
        return Math.max(1, (p.until - System.currentTimeMillis() + 59_999L) / 60_000L);
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT).replace(' ', '_').replace('.', '_');
    }

    private Player findOnline(String arg) {
        String k = key(arg);
        for (Player p : new ArrayList<>(getServer().getOnlinePlayers().values())) {
            if (key(p.getName()).equals(k)) return p;
        }
        return null;
    }

    private static Long parseMinutes(String s, int max) {
        if (!s.matches("\\d{1,9}")) return null;
        long v = Long.parseLong(s);
        if (v < 1 || v > max) return null;
        return v;
    }

    private static String parseReason(String[] a, int from, int maxLen) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < a.length; i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(a[i]);
        }
        String r = TextFormat.clean(sb.toString()).trim();
        if (r.isEmpty() || r.length() > maxLen) return null;
        return r;
    }

    private static String fmt(long minutes) {
        long d = minutes / 1440;
        long h = (minutes % 1440) / 60;
        long m = minutes % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("д ");
        if (h > 0) sb.append(h).append("ч ");
        if (m > 0 || sb.length() == 0) sb.append(m).append("м");
        return sb.toString().trim();
    }

    private int cfgInt(String path, int def) {
        return getConfig().getInt(path, def);
    }

    private String msg(String key, Object... kv) {
        String s = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        }
        return TextFormat.colorize('&', s);
    }
}
